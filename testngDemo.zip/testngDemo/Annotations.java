package testngDemo;

public class Annotations {

//	@BeforeMethod
//	@AfterMethod
//	
//	@BeforeClass
//	@AfterClass
//	
//	@BeforeSuite
//	@Aftersuite
//	
//	@BeforeTest
//	@AfterTest
//	
//	@Test

}
