package testngDemo;

import java.util.ArrayList;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SwitchingWindowsDemo {
	
	ChromeDriver driver;

	@BeforeTest
	public void launchApplication() {
		// 1) Open the browser
		driver = new ChromeDriver();
		// 2) Maximize it
		driver.manage().window().maximize();
		// 3) Navigate to application
		driver.get("https://retail.onlinesbi.com/retail/login.htm");
	}
	
	@Test
	public void switchFocusOnNewWindow() {
		//	4) Click on 'CONTINUE TO LOGIN' button
		driver.findElementByLinkText("CONTINUE TO LOGIN").click();
		
		//	5) Click on 'Forgot Login Password'
		driver.findElementByLinkText("Forgot Login Password").click();
		
		//	6) Shift focus on new window
		ArrayList<String> windows = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(windows.get(1));
		
		//	7) Select 'Forgot Username' from the dropdown
		WebElement credentialsResetDropDown = driver.findElementByName("issueCode");
		Select select = new Select(credentialsResetDropDown);
		select.selectByVisibleText("Forgot Username");
		
		//	8) Click on 'Next' button
		driver.findElementById("nextStep").click();
	}

}
