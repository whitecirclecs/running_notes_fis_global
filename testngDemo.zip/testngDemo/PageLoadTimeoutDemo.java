package testngDemo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PageLoadTimeoutDemo {
	
ChromeDriver driver;
	
	@BeforeTest
	public void launchApplication() {
		//	1) Open the browser
		driver = new ChromeDriver();
		//	2) Maximize it
		driver.manage().window().maximize();		
		//	3) Navigate to application
		driver.get("https://amazon.in/");
	}
	
	@Test
	public void loadPage() {
		driver.manage().timeouts().pageLoadTimeout(1, TimeUnit.SECONDS);
	}

}
