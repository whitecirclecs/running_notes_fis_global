package testngDemo;

import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class VerifyTitleOnEdge {
	
	EdgeDriver driver;

	@BeforeTest
	public void launchApplication() {
		// 1) Open the browser
		System.setProperty("webdriver.edge.driver", "msedgedriver.exe");
		driver = new EdgeDriver(); // Class object = new Class()

		// Delete the cookies
		driver.manage().deleteAllCookies();
		
		//Maximize the browser
		driver.manage().window().maximize();
		
		// 2) Navigate to application
		driver.get("https://www.linkedin.com/");
	}

	@Test
	public void titleVerification() {
		String expectedTitle = "LinkedIn: Log In or Sign Up";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, expectedTitle);
	}

	@AfterTest
	public void closeBrowser() {
		driver.quit();
	}

}
