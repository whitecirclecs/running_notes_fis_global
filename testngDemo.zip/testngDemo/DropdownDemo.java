package testngDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class DropdownDemo {
	
ChromeDriver driver;
	
	@BeforeTest
	public void launchApplication() {
		//	1) Open the browser
		driver = new ChromeDriver();
		//	2) Maximize it
		driver.manage().window().maximize();		
		//	3) Navigate to application
		driver.get("https://en-gb.facebook.com/");
	}
	
	@Test
	public void clickMaleRadioBtn() throws InterruptedException {
		//	4) Click on 'Create New Account' button
		driver.findElementByLinkText("Create New Account").click();
		
		//Wait for pop up to appear
		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("month")));
		
		//	5) Select month as 'Dec' from month drop down
		WebElement monthDrpDown = driver.findElementById("month");
		Select select = new Select(monthDrpDown);
		select.selectByVisibleText("Dec");
		
	}

}
