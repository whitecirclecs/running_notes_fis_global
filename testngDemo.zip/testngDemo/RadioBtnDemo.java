package testngDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class RadioBtnDemo {
	
	ChromeDriver driver;
	
	@BeforeTest
	public void launchApplication() {
		//	1) Open the browser
		driver = new ChromeDriver();
		//	2) Maximize it
		driver.manage().window().maximize();		
		//	3) Navigate to application
		driver.get("https://en-gb.facebook.com/");
	}
	
	@Test
	public void clickMaleRadioBtn() throws InterruptedException {
		//	4) Click on 'Create New Account' button
		driver.findElementByLinkText("Create New Account").click();
		
		//Wait for pop up to appear
		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[contains(@type,'radio')])[2]")));
		
		//	5) Click on 'Male' radio button
		driver.findElementByXPath("(//input[contains(@type,'radio')])[2]").click();
	}
	

}
