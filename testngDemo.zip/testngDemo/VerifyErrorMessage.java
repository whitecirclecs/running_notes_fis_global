package testngDemo;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class VerifyErrorMessage {
	ChromeDriver driver;
	
	@BeforeTest
	public void launchApplication() {
		//	1) Open the browser
		driver = new ChromeDriver();
		
		//	2) Maximize the browser
		driver.manage().window().maximize();
		
		//	3) Navigate to application
		driver.get("https://en-gb.facebook.com/");
	}
	
	@Test
	public void verifyMessage() {
		//	4) Enter an invalid username
		driver.findElementById("email").sendKeys("batman554466@gmail.com");
		
		//	5) Enter an invalid password
		driver.findElementById("pass").sendKeys("password123");
		
		//	6) Click on Login button
		driver.findElementByName("login").click();
		
		//	7) Verify the error message- 'The email address you entered isn't connected to an account. Find your account and log in.' is displayed.
		String expectedErrMsg = "The email address you entered isn't connected to an account. Find your account and log in.";
		String actualErrMsg = driver.findElementByCssSelector("#email_container > div._9ay7").getText();
		Assert.assertEquals(actualErrMsg, expectedErrMsg);		
		
	}
	
	//	8) Close the browser
	@AfterTest
	public void closeBRowser() {
		driver.quit();
		
	}
	
	
	
}
