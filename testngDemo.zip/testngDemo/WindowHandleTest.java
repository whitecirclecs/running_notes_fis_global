package testngDemo;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class WindowHandleTest {
	
	@Test
	public void openBrowser() {
		ChromeDriver driver = new ChromeDriver();
		System.out.println(driver.getWindowHandle());
	}

}
