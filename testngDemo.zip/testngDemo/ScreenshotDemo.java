package testngDemo;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ScreenshotDemo {
	

	ChromeDriver driver;

	@BeforeTest
	public void launchApplication() {
		// 1) Open the browser
		driver = new ChromeDriver();
		// 2) Maximize it
		driver.manage().window().maximize();
		// 3) Navigate to application
		driver.get("https://amazon.in");
	}
	
	@Test
	public void hoverPointer() throws IOException {
		try {
			//	4) Hover pointer over 'Hello Sign in' menu
			WebElement signInMenu = driver.findElementById("nav-link-accountList");
			Actions actions = new Actions(driver);
			actions.moveToElement(signInMenu).build().perform();
			
			//	5) Click on 'Sign-in' btn in the sub menu
			driver.findElementByLinkText("Sign inn").click();
		}
		catch(Exception e) {
			getScreenshot();
			Assert.assertTrue(false);
		}
	}

	private void getScreenshot() throws IOException {
		File ss = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);  //Take screenshot
		FileHandler.copy(ss, new File("D:\\TestExecutionSS\\screengrab.png")); //Save the screenshot in some location
		
	}

}
