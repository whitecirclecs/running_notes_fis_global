package testngDemo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class WebTableDemo {
	
ChromeDriver driver;
	
	@BeforeTest
	public void launchApplication() {
		//	1) Open the browser
		driver = new ChromeDriver();
		//	2) Maximize it
		driver.manage().window().maximize();		
		//	3) Navigate to application
		driver.get("https://www.bseindia.com/markets/debt/debt_corporate_EOD.aspx?curPage=1");
	}
	
	@Test
	public void clickLiquidBees() {
		//	4) Click on 'LIQUIDBEES' in the webtable
		// 4.1 Locate the webtable
		WebElement table = driver.findElementById("ContentPlaceHolder1_GridViewrcdsFC");
		
		//4.2 Get all the rows from the table and put them in the list 
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		
		//4.3 Pick one row at a time 
		boolean valueFound = false;
		for(int i=1; i<rows.size(); i++) {
			WebElement row = rows.get(i);
			
			//4.4 Create another list of all the cell values (i.e. td tags) from the selected row
			List<WebElement> columns = row.findElements(By.tagName("td"));
			
			//4.5 Iterate through all the values of the columns list and see if it contains the text 'LIQUIDBEES'
			for(WebElement x : columns) {
				if(x.getText().contains("LIQUIDBEES")) {
					x.click();
					valueFound = true;
					break;
				}
			}
			
			if(valueFound == true) {
				break;
			}
			
		}
		
		
		
	}

}
