package testngDemo;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AlertBoxDemo {

	ChromeDriver driver;

	@BeforeTest
	public void launchApplication() {
		// 1) Open the browser
		driver = new ChromeDriver();
		// 2) Maximize it
		driver.manage().window().maximize();
		// 3) Navigate to application
		driver.get("https://retail.onlinesbi.com/retail/login.htm");
	}

	@Test
	public void closeAlertBox() throws InterruptedException {
		// 4) Click on 'CONTINUE TO LOGIN' button
		driver.findElementByLinkText("CONTINUE TO LOGIN").click();
		
		// 5) Click on 'Login' button
		driver.findElementById("Button2").click();
		
		Thread.sleep(5000);
		
		// 6) Close the alert box by clicking OK button
		driver.switchTo().alert().accept();
		
		// Close the alert box by clicking Cancel button
		driver.switchTo().alert().dismiss();
	}
	
	

}
