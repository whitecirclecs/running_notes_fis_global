package testngDemo;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FramesDemo {
	
	ChromeDriver driver;

	@BeforeTest
	public void launchApplication() {
		// 1) Open the browser
		driver = new ChromeDriver();
		// 2) Maximize it
		driver.manage().window().maximize();
		// 3) Navigate to application
		driver.get("https://www.selenium.dev/selenium/docs/api/java/index.html?overview-summary.html");
	}
	
	@Test
	public void clickDeprecatedHyperlink() throws InterruptedException {
		
		// 3.1) Go inside the frame
		driver.switchTo().frame("classFrame");
		
		//	4) Click on 'Deprecated' hyperlink
		driver.findElementByLinkText("DEPRECATED").click();
	}

	

}
