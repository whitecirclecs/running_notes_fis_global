package testngDemo;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class UploadFile {
	
	ChromeDriver driver;

	@BeforeTest
	public void launchApplication() {
		// 1) Open the browser
		driver = new ChromeDriver();
		// 2) Maximize it
		driver.manage().window().maximize();
		// 3) Navigate to application
		driver.get("https://doctopdf.com/");
	}
	
	@Test
	public void testFileUpload() throws IOException, InterruptedException {
		//	4) Click on 'UPLOAD FILES' button
		driver.findElementByXPath("//label[contains(@aria-label,'Upload Files')]").click();
		
		Thread.sleep(3000);
		
		//	5) Upload any file from the computer.
		Runtime.getRuntime().exec("FileUpload.exe");
	}
	

}
