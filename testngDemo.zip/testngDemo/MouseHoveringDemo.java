package testngDemo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class MouseHoveringDemo {
	
	ChromeDriver driver;

	@BeforeTest
	public void launchApplication() {
		// 1) Open the browser
		driver = new ChromeDriver();
		// 2) Maximize it
		driver.manage().window().maximize();
		// 3) Navigate to application
		driver.get("https://amazon.in");
	}
	
	@Test
	public void hoverPointer() {
		//	4) Hover pointer over 'Hello Sign in' menu
		WebElement signInMenu = driver.findElementById("nav-link-accountList");
		Actions actions = new Actions(driver);
		actions.moveToElement(signInMenu).build().perform();
		
		//	5) Click on 'Sign-in' btn in the sub menu
		driver.findElementByLinkText("Sign in").click();
	}
	


}
