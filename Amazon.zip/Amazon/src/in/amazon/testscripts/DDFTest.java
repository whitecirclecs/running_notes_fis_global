package in.amazon.testscripts;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import in.amazon.pages.LandingPage;
import in.amazon.pages.SignIn;
import utils.ReadExcel;

public class DDFTest extends BaseTest {

	@Test
	public void verifyInvalidUserCannotLogin() throws IOException, InterruptedException {
		// 4) Hover pointer over 'Hello Sign in' menu
		LandingPage landingPage = new LandingPage(driver);
		landingPage.hoverPointerOverHelloSignIn();

		// 5) Click on 'Sign in button in the sub-menu
		landingPage.clickSignInBtn();

		// 6) Enter an invalid username
		SignIn signIn = new SignIn(driver);
		
		String[][] data = ReadExcel.getData("TestData.xlsx", "Sheet1");
		
		for(int i=1; i<6; i++) {
			String username = data[i][1];
			signIn.enterUsername(username);
			
			Thread.sleep(3000);
			// 7) Click on 'Continue' button
			signIn.clickContinueBtn();
	
			// 8) Verify the error message - We cannot find an account with that email
			// address - is displayed.
			String expectedErrMsg = "We cannot find an account with that email address";
			String actualErrMsg = signIn.getErrMsg();
			Assert.assertEquals(actualErrMsg, expectedErrMsg);
		}
	}

}
