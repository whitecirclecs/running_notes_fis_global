package in.amazon.testscripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import in.amazon.pages.LandingPage;
import in.amazon.pages.SignIn;

public class InvalidUserTest extends BaseTest {
	
	@Test
	public void verifyInvalidUserCannotLogin() {
		// 4) Hover pointer over 'Hello Sign in' menu
		LandingPage landingPage = new LandingPage(driver);
		landingPage.hoverPointerOverHelloSignIn();

		// 5) Click on 'Sign in button in the sub-menu
		landingPage.clickSignInBtn();

		// 6) Enter an invalid username
		SignIn signIn = new SignIn(driver);
		signIn.enterUsername("batman554466@gmail.com");

		// 7) Click on 'Continue' button
		signIn.clickContinueBtn();

		// 8) Verify the error message - We cannot find an account with that email
		// address - is displayed.
		String expectedErrMsg = "We cannot find an account with that email address";
		String actualErrMsg = signIn.getErrMsg();
		Assert.assertEquals(actualErrMsg, expectedErrMsg);
	}


}
