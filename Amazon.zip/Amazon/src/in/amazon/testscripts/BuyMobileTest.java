package in.amazon.testscripts;

import java.util.ArrayList;
import org.testng.Assert;
import org.testng.annotations.Test;
import in.amazon.pages.ApplePhones;
import in.amazon.pages.BuyPhone;
import in.amazon.pages.LandingPage;
import in.amazon.pages.MobilePhones;

public class BuyMobileTest extends BaseTest {

	@Test
	public void buyMobile() {
		// 4) Click on Mobiles
		LandingPage landingPage = new LandingPage(driver);
		landingPage.clickMobiles();

		// 5) Hover pointer over 'Mobiles & Accessories'
		MobilePhones mobilePhones = new MobilePhones(driver);
		mobilePhones.hoverOverMobilesAndAccessories();

		// 6) Click on 'Apple' in the sub-menu
		mobilePhones.clickApple();

		// 7) Click on first phone
		ApplePhones applePhones = new ApplePhones(driver);
		applePhones.clickFirstApplePhone();

		// 8) Click on 'Buy Now' button
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		BuyPhone buyPhone = new BuyPhone(driver);
		buyPhone.clickBuyNowBtn();

		// 9) Verify the user is on the 'Sign-In' page
		String expectedTitle = "Amazon Sign In";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, expectedTitle);
	}

}
